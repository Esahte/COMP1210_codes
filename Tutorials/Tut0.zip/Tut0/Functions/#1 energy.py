def energy(mass, c=299792458):
    return mass * c**2


print(energy(400))