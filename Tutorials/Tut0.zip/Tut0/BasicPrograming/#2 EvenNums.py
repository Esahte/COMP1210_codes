prompt = int(input('Enter a number: '))

if prompt%2 == 0: print(0)
else: print(1)