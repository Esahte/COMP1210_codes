def speed(distance, time):
    return f'{round((distance/time)*2.23694, 2)} mph'

print(speed(100, 9.58))