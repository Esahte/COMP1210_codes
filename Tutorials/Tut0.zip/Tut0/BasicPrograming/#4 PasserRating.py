def passerRating(passComp, passAtt, totalPY, touchdowns, interceptions):
    cpa = ((passComp/passAtt)*0.3)/20
    ypa = ((totalPY/passAtt)-3)/4
    tpa = (touchdowns/passAtt)*20
    ipa = 2.375-((interceptions/passAtt)*35)
    return ((cpa+ypa+tpa+ipa)/6)*100


passCompletions = int(input('Enter num of pass completions: '))
passAttempts = int(input('Enter num of passAttempts: '))
totalPassYards = int(input('Enter total pass yards: '))
totalTouchdowns = int(input('Enter num of touchdowns: '))
totalInterceptions = int(input('Enter total interceptions: '))

print(passerRating(passCompletions, passAttempts, totalPassYards, totalTouchdowns, totalInterceptions))