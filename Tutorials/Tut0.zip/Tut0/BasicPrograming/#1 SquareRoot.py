from math import sqrt

prompt = int(input('Enter a number: '))
print(round(sqrt(prompt), 2))